using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using System.Linq;


public class PlotCSV : MonoBehaviour
{
    public string path1 = "Data/Prepped/united-states-gdp-gross-domestic-product.csv";
    public string path2 = "Data/Prepped/united-states-unemployment-rate.csv";
    public char delimiter = ',';
    public float range = 100;
    private void Start()
    {
        // Read the CSV file
        string[] lines1 = File.ReadAllLines(path1);
        string[] lines2 = File.ReadAllLines(path2);
        List<float> x = new List<float>();
        List<float> y = new List<float>();
        List<float> z = new List<float>();

        for (int i = 1; i<lines1.Length; ++i)
        {
            string line = lines1[i];
            string line2 = lines2[i];
            string[] values = line.Split(delimiter);
            string[] values2 = line2.Split(delimiter);

            x.Add(float.Parse(values[0].Substring(0,4)));
            y.Add(float.Parse(values[1].Replace('.',',')));
            z.Add(float.Parse(values2[1].Replace('.',',')));
            // Create a new sphere at the specified coordinates

        }
        x = Normalize(x, range);
        y = Normalize(y, range);
        z = Normalize(z, range);
        
        for (int i = 0; i < x.Count; ++i)
        {
            GameObject sphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            sphere.transform.position = new Vector3(x[i], y[i], z[i]);
        }
        
    }
    static List<float> Normalize(List<float> input, float range = 10)
{
    float max = input.Max();
    float min = input.Min();
    max = max - min;

    for (int i = 0; i<input.Count(); ++i)
    {
        input[i] -= min;
        input[i] /= max;
        input[i] *= range;
    }
    return input;
}

    // Update is called once per frame
    void Update()
    {
        
    }
}
